<?php
/**
 * Created by PhpStorm.
 * User: storyteller
 * Date: 7/3/15
 * Time: 11:41 AM
 */

the_title();