<div class="row">
            <div class="col-md-12">
                <header class="banner2">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="banner-text">
                                    <h1>Some Advertisement Heading</h1>

                                    <h2>Some description about the advertisement</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
            </div>
        </div>

<div class="row">